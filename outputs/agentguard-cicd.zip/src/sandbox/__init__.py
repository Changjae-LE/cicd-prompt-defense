from .environment import FakeEnvironment

